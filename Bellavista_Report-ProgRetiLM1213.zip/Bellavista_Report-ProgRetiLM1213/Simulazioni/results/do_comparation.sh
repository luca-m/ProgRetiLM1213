#!/bin/bash

rm res_exp_1
rm res_det_1

for i in {1..100} ; do
  ./../bin/mg1prio $i exp 100000 1 0.8 10 | grep -o -m1 -e "[0-9]*\.[0-9]*" >> res_exp_1
  ./../bin/mg1prio $i det 100000 1 0.8 10 | grep -o -m1 -e "[0-9]*\.[0-9]*" >> res_det_1
done

Rscript ./comparator.R
