#!/bin/bash

rm res_prio2
rm res_prio3_1
rm res_prio3_2
rm res_prio3_3

STEPS=100
RHO="0.8"
for d in $(seq 1 `expr $STEPS - 1`); do
  x=$(echo "$d/$STEPS"|bc -l)
  # 2 Classes
  rho2_1=$(echo "$x*$RHO"|bc -l)
  rho2_2=$(echo "(1-$x)*$RHO"|bc -l)
  # 3 Classes, 1st case
  rho31_1=$(echo "$x/2*$RHO"|bc -l)
  rho31_2=$rho31_1
  rho31_3=$(echo "(1-$x)*$RHO"|bc -l)
  # 3 Classes, 2nd case
  rho32_1=$(echo "$x/10*$RHO"|bc -l)
  rho32_2=$(echo "$x*9/10*$RHO"|bc -l)
  rho32_3=$(echo "(1-$x)*$RHO"|bc -l)
  # 3 Classes, 3rd case
  rho33_1=$(echo "$x*$RHO"|bc -l)
  rho33_2=$(echo "(1-$x)/2*$RHO"|bc -l)
  rho33_3=$rho33_2

  for i in {1..100} ; do
    ./../bin/mg1prio $i exp 100000 2 $rho2_1 10 $rho2_2 10 | grep -o -e "[0-9]*\.[0-9]*" | tr "\n" "," >> res_prio2

    ./../bin/mg1prio $i exp 100000 3 $rho31_1 10 $rho31_2 10 $rho31_3 10  | grep -o -e "[0-9]*\.[0-9]*" | tr "\n" "," >> res_prio3_1
    ./../bin/mg1prio $i exp 100000 3 $rho32_1 10 $rho32_2 10 $rho32_3 10 | grep -o -e "[0-9]*\.[0-9]*" | tr "\n" "," >> res_prio3_2
    ./../bin/mg1prio $i exp 100000 3 $rho33_1 10 $rho33_2 10 $rho33_3 10 | grep -o -e "[0-9]*\.[0-9]*" | tr "\n" "," >> res_prio3_3
  done
  echo "" >> res_prio2
  echo "" >> res_prio3_1
  echo "" >> res_prio3_2
  echo "" >> res_prio3_3
done

# Remove the trailing ',' at the end of each line
for i in res_prio2 res_prio3_1 res_prio3_2 res_prio3_3 ; do
  sed -i 's/,$//' $i
done

Rscript ./prio.R
