# function confidenceInterval -
#  compute the confidence interval of the given
# samples using the student's T distribution
confidenceInterval <- function(samples, confidenceLevel=0.95) {
  sampleVariance <- var(samples)
  n <- length(samples)
  sampleMean <- mean(samples)
  # Compute the Student T confidence parameter
  delta <- qt(confidenceLevel, df<-n - 1) * sampleVariance / sqrt(n)
  return(c(sampleMean - delta, sampleMean, sampleMean + delta))
}

# function theoreticalexp -
# Compute the eta for exponential distribution
# using analytical formula
theoreticalExp <- function(theta) {
  rho <- seq(1/1000, 1, 1/1000);
  eta <- rho / (1 - rho) * theta
  return(eta)
}

# function theoreticaldet -
# Compute the eta for deterministic distribution
# using analytical formula
theoreticalDet <- function(theta) {
  rho <- seq(1/1000, 1, 1/1000);
  eta <- rho / (1 - rho) * theta/2
  return(eta)
}

# Read the simulation result of the exponential distribution
expD <- read.table('./res_exp_2', sep=',')
# Apply to each row of exp the function confidenceInterval(row, 0.95)
expDres <- apply(expD, 1, confidenceInterval, 0.95)
# Read the simulation result of the deterministic distribution
detD <- read.table('./res_det_2', sep=',')
# Apply to each row of det the function confidenceinterval(row, 0.95)
detDres <- apply(detD, 1, confidenceInterval, 0.95)
# Compute eta using analytical formula for exp distrib
therexpD<- theoreticalExp(10)
# Compute eta using analytical formula for det distrib
therdetD <- theoreticalDet(10)
