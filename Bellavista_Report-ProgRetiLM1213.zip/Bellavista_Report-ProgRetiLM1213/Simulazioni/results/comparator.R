# function confidenceInterval -
# compute the confidence interval of the given
# samples using the student's T distribution
confidenceInterval <- function(samples, confidenceLevel) {
  sampleVariance <- var(samples)
  n <- length(samples)
  sMean <- mean(samples)
  # Compute the Student T confidence parameter
  delta <- qt(confidenceLevel, df<-n - 1) * sampleVariance / sqrt(n)
  return(c(sMean - delta, sMean + delta))
}

printInfo <- function(samples, confLevel) {
  m <- mean(samples)
  v <- var(samples)
  vm <- v/length(samples)
  ci <- confidenceInterval(samples, confLevel)
  cat("\tMedia campionaria:", m, "\n")
  cat("\tVarianza campionaria:", v, "\n")
  cat("\tVarianza valor medio:", vm, "\n")
  cat("\tIntervallo di confidenza con affidabilità", confLevel, ":", ci, "\n")
}

det <- unlist(read.table("res_det_1"), use.names = FALSE)
cat("Simulazione con distribuzione deterministica\n")
printInfo(det, 0.95)

exp <- unlist(read.table("res_exp_1"), use.names = FALSE)
cat("Simulazione con distribuzione esponenziale\n")
printInfo(exp, 0.95)

