# function confidenceInterval - compute the confidence interval of the given
# samples using the student's T distribution
confidenceInterval <- function(samples, confidence_level=0.95) {
  samplevariance <- var(samples)
  n <- length(samples)
  samplemean <- mean(samples)
  # Compute the Student T confidence parameter
  delta <- qt(confidence_level, df=n - 1) * samplevariance / sqrt(n)
  return(c(samplemean - delta, samplemean, samplemean + delta))
}

confidenceIntervalFull <- function(samples, ndata, keep, confidence_level=0.95) {
  cols <- length(samples) / ndata
  matSamples = matrix(samples, nrow=ndata, ncol=cols)[1:keep,]
  return(apply(matSamples, 1, confidenceInterval, 0.95))
}

myComparativePlot <- function(x, samples, plotTitle, pngFile, legend) {
  size <- dim(samples)[1]/3
  dim(samples)
  colors <- c("black", "red", "blue", "green", "orange")[1:size]
  kLty <- rep(1, size)
  kLwd <- rep(2.5, size)

  png(pngFile, width = 1000, height = 1000)
  par(las = 2)
  plot(x, x, type='n', xlab="ρ", ylab=expression(bar("η")), main=plotTitle, ylim=c(0, max(samples)), cex.lab=1.2, cex.main=2.0)
  for (i in seq(0, size - 1)) {
    y <- samples[i*3+2,]
    confLB <- samples[i*3+1,]
    confUB <- samples[i*3+3,]
    lines(x, y, col=colors[i+1])
    segments(x,confLB,x,confUB, col=colors[i+1])
  }
  legend(0.0, max(samples) , legend, lty=kLty, lwd=kLwd,col=colors, cex=2)
  dev.off()
}

# Read the simulation results
prio_n2 <- read.table('./res_prio2', sep=',')
prio_n3_1 <- read.table('./res_prio3_1', sep=',')
prio_n3_2 <- read.table('./res_prio3_2', sep=',')
prio_n3_3 <- read.table('./res_prio3_3', sep=',')

prio_n2_res = apply(prio_n2, 1, confidenceIntervalFull, 3, 2, 0.95)
prio_n31_res = apply(prio_n3_1, 1, confidenceIntervalFull, 4, 3, 0.95)
prio_n32_res = apply(prio_n3_2, 1, confidenceIntervalFull, 4, 3, 0.95)
prio_n33_res = apply(prio_n3_3, 1, confidenceIntervalFull, 4, 3, 0.95)

step <- 100
x <- seq(1/step, 1 - 1/step, 1/step)

e1 <- expression(bar("η")[1])
e2 <- expression(bar("η")[2])
e3 <- expression(bar("η")[3])
em <- expression(bar("η")["mm1"])

# Read the simulation result of the exponential distribution
expD <- unlist(read.table('./res_exp_3', sep=',', header=F))
# Apply to each row of exp the function confidenceInterval(row, 0.95)
expD_res <- confidenceInterval(expD, 0.95)

expD_res <- matrix(data=rep(expD_res, dim(prio_n2_res)[2]), nrow=3)

prio_n2_res <- rbind(prio_n2_res, expD_res)
prio_n31_res <- rbind(prio_n31_res, expD_res)
prio_n32_res <- rbind(prio_n32_res, expD_res)
prio_n33_res <- rbind(prio_n33_res, expD_res)

myComparativePlot(x, prio_n2_res, "Priority scheduling. 2 classes", "prio2.png", c(e1,e2, em))
myComparativePlot(x, prio_n31_res, "Priority scheduling. 3 classes, 1st case", "prio31.png", c(e1, e2, e3, em))
myComparativePlot(x, prio_n32_res, "Priority scheduling. 3 classes, 2nd case", "prio32.png", c(e1, e2, e3, em))
myComparativePlot(x, prio_n33_res, "Priority scheduling. 3 classes, 3rd case", "prio33.png", c(e1, e2, e3, em))


