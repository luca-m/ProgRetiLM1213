# function confidenceInterval - compute the confidence interval of the given
# samples using the student's T distribution
confidenceInterval <- function(samples, confidence_level=0.95) {
  samplevariance <- var(samples)
  n <- length(samples)
  samplemean <- mean(samples)
  # Compute the Student T confidence parameter
  delta <- qt(confidence_level, df=n - 1) * samplevariance / sqrt(n)
  return(c(samplemean - delta, samplemean, samplemean + delta))
}

myPlot <- function(x, samples, plotTitle, pngFile) {
  y <- samples[2,]
  confLB <- samples[1,]
  confUB <- samples[3,]
  png(pngFile, width = 1000, height = 1000)
  plot(x, y, type='l', xlab="ρ", ylab=expression(bar("η")), main=plotTitle, cex.lab=1.2, cex.main=2.0)
  segments(x,confLB,x,confUB)
}

myComparativePlot <- function(x, samplesTh, samplesSim, plotTitle, pngFile, legend1, legend2) {
  if(is.null(dim(samplesTh))) {
    y1 <- samplesTh
    confLB1 <- samplesTh
    confUB1 <- samplesTh
  } else {
    y1 <- samplesTh[2,]
    confLB1 <- samplesTh[1,]
    confUB1 <- samplesTh[3,]
  }
  
  y2 <- samplesSim[2,]
  confLB2 <- samplesSim[1,]
  confUB2 <- samplesSim[3,]
  png(pngFile, width = 1000, height = 1000)
  plot(x, y1, type='n', xlab="ρ", ylab=expression(bar("η")), main=plotTitle, cex.lab=1.2, cex.main=2.0)
  lines(x, y2, col="red")
  segments(x,confLB2,x,confUB2, col="red")
  lines(x, y1)
  segments(x,confLB1,x,confUB1)
  legend(0.0, y1[900] ,c(legend1, legend2), lty=c(1,1), lwd=c(2.5,2.5),col=c("black","red"), cex=2.0)
  dev.off()
}

# function theoretical_exp -
# Compute the eta for exponential distribution
# using analytical formula
theoreticalExp <- function(theta) {
  rho <- seq(1/1000, 1, 1/1000);
  eta <- rho / (1 - rho) * theta
  return(eta)
}

# function theoretical_det -
# Compute the eta for deterministic distribution
# using analytical formula
theoreticalDet <- function(theta) {
  rho <- seq(1/1000, 1, 1/1000);
  eta <- rho / (1 - rho) * theta/2
  return(eta)
}

# Read the simulation result of the exponential distribution
expD <- read.table('./res_exp_2', sep=',')
# Apply to each row of exp the function confidenceInterval(row, 0.95)
expD_res <- apply(expD, 1, confidenceInterval, 0.95)
# Read the simulation result of the deterministic distribution
detD <- read.table('./res_det_2', sep=',')
# Apply to each row of det the function confidence_interval(row, 0.95)
detD_res <- apply(detD, 1, confidenceInterval, 0.95)
# Compute eta using analytical formula for exp distrib
ther_expD<- theoreticalExp(10)
# Compute eta using analytical formula for det distrib
ther_detD <- theoreticalDet(10)

# Take only the results for rho in [0.001, 0.9]
xVals <- 1:900;
myPlot(xVals/1000, expD_res[,xVals], "Distribuzione Esponenziale", "SimExp.png")
myPlot(xVals/1000, detD_res[,xVals], "Distribuzione Deterministica", "SimDet.png")
myComparativePlot(xVals/1000, expD_res[,xVals], detD_res[,xVals], "Confronto fra distribuzione esponenziale e deterministica", "CompExpDet.png", "Esponenziale", "Deterministica")
myComparativePlot(xVals/1000, ther_expD[xVals], expD_res[,xVals], "Distribuzione esponenziale, confronto con risultato teorico", "CompExp.png", "Teorico", "Simulato")
myComparativePlot(xVals/1000, ther_detD[xVals], detD_res[,xVals], "Distribuzione deterministica, confronto con risultato teorico", "CompDet.png", "Teorico", "Simulato")
