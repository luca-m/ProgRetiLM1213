#!/bin/bash

rm res_exp_2
rm res_det_2

STEPS=1000
for d in $(seq 1 $STEPS); do
  rho=$(echo "$d/$STEPS"|bc -l)
  for i in {1..100} ; do
    ./../bin/mg1prio $i exp 100000 1 $rho 10 | grep -o -m1 -e "[0-9]*\.[0-9]*" | tr "\n" "," >> res_exp_2
    ./../bin/mg1prio $i det 100000 1 $rho 10 | grep -o -m1 -e "[0-9]*\.[0-9]*" | tr "\n" "," >> res_det_2
  done
  echo "" >> res_exp_2
  echo "" >> res_det_2
done
# Remove the trailing ',' at the end of each line
sed -i 's/,$//' res_exp_2
sed -i 's/,$//' res_det_2

Rscript ./mg1.R
